"""A prompt library for rplugin in Neovim."""
__author__ = 'lambdalisue'
__license__ = 'MIT'
