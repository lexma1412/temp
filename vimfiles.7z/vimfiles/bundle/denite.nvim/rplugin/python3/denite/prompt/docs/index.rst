.. neovim-prompt documentation master file, created by
   sphinx-quickstart on Mon Oct 17 02:31:01 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Contents
------------------------

.. toctree::
   :maxdepth: 4

   prompt


Indices and tables
-----------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

